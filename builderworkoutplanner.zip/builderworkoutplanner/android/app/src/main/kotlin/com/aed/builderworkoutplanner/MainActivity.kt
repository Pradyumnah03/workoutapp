package com.aed.builderworkoutplanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
