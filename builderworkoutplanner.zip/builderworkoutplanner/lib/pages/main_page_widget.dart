import 'dart:math';
import 'dart:ui';

import 'package:builderworkoutplanner/models/exercise_model.dart';
import 'package:builderworkoutplanner/models/time_helper.dart';
import 'package:builderworkoutplanner/pages/workout_page.dart';
import 'package:builderworkoutplanner/widgets/listview_card.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../data.dart';
import 'add_new_page.dart';

class MainPageWidget extends StatefulWidget {
  final dataRquiredForBuild;
  const MainPageWidget({Key? key, this.dataRquiredForBuild}) : super(key: key);

  @override
  _MainPageWidgetState createState() => _MainPageWidgetState();
}

class _MainPageWidgetState extends State<MainPageWidget> {
  int currentIndext = 0;
  int imageIndex = 1;
  int listviewItemCount = 0;
  int workoutDuration = 0;
  List<NamesOfPlans> tableList = [];
  var tablename;
  List<Company> workoutsLists = [];
  Map data = {};

  @override
  void initState() {
    // TODO: implement initState
    dataLoader();
    dbCreator().then((value) {
      return null;
    });
    super.initState();
  }

  dataLoader() async {
    data = await TimeHelper.dataGetter('Settings', 'Setting');
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.topCenter,
      child: Column(children: [
        SizedBox(
          height: size.height * .05,
        ),
        Container(
          padding: EdgeInsets.all(15),
          alignment: Alignment.topLeft,

          // ignore: prefer_const_literals_to_create_immutables
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              // ignore: prefer_const_literals_to_create_immutables
              children: [
                // ignore: prefer_const_constructors
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Hey ${data['Name']}",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        // ignore: prefer_const_constructors
                        Text(
                          "Don't Miss The Fitness! ",
                          // ignore: prefer_const_constructors
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                    SizedBox(
                      width: size.width * .09,
                    ),
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(
                            Radius.circular(50),
                          ),
                          border: Border.all(color: Color(secondColor))),
                      child: Container(
                          margin: EdgeInsets.all(10),
                          child: Image(
                            image: AssetImage(data['Gender'] == 1
                                ? "assets/icons/male.jpg"
                                : "assets/icons/female.jpg"),
                            height: 40,
                            width: 40,
                          )),
                    )
                  ],
                )
              ]),
        ),
        Container(
          height: size.height * .08,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,

            // ignore: prefer_const_literals_to_create_immutables
            children: [
              const Text(
                "Your Plans",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              TextButton(
                style: TextButton.styleFrom(
                  primary: Colors.grey[500],
                  textStyle: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.bold),
                ),
                onPressed: () async {
                  Navigator.push(context, MaterialPageRoute(builder: (c) {
                    return secondPage();
                  }));
                },
                child: const Text("Add New "),
              )
            ],
          ),
        ),
        Expanded(
            child: (tableList.length == 0)
                ? Column(
                    children: [
                      Image.asset("assets/images/empty.jpg"),
                      Text(
                        "Nothing is here! \n Click Add New to add new plans :)",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ],
                  )
                : ListView.builder(
                    itemCount: tableList.length,
                    itemBuilder: (context, index) {
                      return FutureBuilder(
                          future: listData(index),
                          builder:
                              (BuildContext contexr, AsyncSnapshot snapshot) {
                            if (snapshot.hasData) {
                              if (imageIndex > 11) {
                                imageIndex = 1;
                              } else {
                                imageIndex++;
                              }
                              // print(snapshot.data);
                              List<Company> data = snapshot.data!;
                              return PlansCards(
                                onTap: () async {
                                  await Navigator.push(context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) {
                                    return WorkoutPage(
                                      workoutName: tableList[index].name,
                                    );
                                  }));
                                },
                                icon: IconButton(
                                  icon: Icon(Icons.delete),
                                  onPressed: () async {
                                    await dbDeleter(index);
                                    setState(() {});
                                  },
                                ),
                                image: Image.asset(
                                    'assets/images/$imageIndex.jpg'),
                                size: size,
                                title: tableList[index].name,
                                subTitle: 'Duration : ${data.length}',
                                titleFontSize: size.height * 0.0265,
                              );
                            } else {
                              //   print(snapshot.error);
                              return Center();
                            }
                          });
                    }))
      ]),
    );
  }

  Future<List<Company>> listData(index) async {
    final db = await openDatabase(join(await getDatabasesPath(), 'names.db'),
        version: 2);
    tablename = tableList[index].name;

    final List<Map<String, dynamic>> maps = await db.query('"$tablename"');

    workoutsLists = List.generate(maps.length, (index) {
      return Company(
          id: index,
          howto: maps[index]['HOWTO'],
          imgurl: maps[index]['IMGURL'],
          name: maps[index]['NAME'],
          usage: maps[index]['USAGE'],
          sort: index);
    });
    workoutDuration = workoutsLists.length;
    return workoutsLists;
  }

  Future dbCreator() async {
    print('Starting Creating db');
    final database = await openDatabase(
      join(await getDatabasesPath(), 'names.db'),
    );

    List<Map<String, dynamic>> tmp =
        await database.rawQuery("SELECT * FROM sqlite_master ");
    tableList = List.generate(tmp.length - 1,
        (index) => NamesOfPlans(id: index, name: tmp[index + 1]['name']));
    print(tableList);

    setState(() {});

    return tableList;
  }

  dbDeleter(int index) async {
    final db = await openDatabase(join(await getDatabasesPath(), 'names.db'),
        version: 2);

    try {
      await db.execute('DROP TABLE "${tableList[index].name}"');

      List<Map<String, dynamic>> maps = await db.query('names');
      listviewItemCount = maps.length;
      tableList = List.generate(maps.length, (index) {
        return NamesOfPlans(
          id: index,
          isUsed: maps[index]['ISUSED'],
          name: maps[index]['NAME'],
        );
      });
    } catch (e) {
      print(e);
    }

    await db.close();
  }
}
