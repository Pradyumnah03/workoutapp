import 'package:builderworkoutplanner/data.dart';
import 'package:builderworkoutplanner/models/exercise_model.dart';
import 'package:builderworkoutplanner/pages/home_page.dart';
import 'package:builderworkoutplanner/widgets/bottom_popup.dart';
import 'package:builderworkoutplanner/widgets/listview_card.dart';
import 'package:builderworkoutplanner/widgets/rounded_text_field.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../data.dart';
import 'add_exercise_page.dart';
import 'package:path/path.dart';

class secondPage extends StatefulWidget {
  final tableName;
  const secondPage({Key? key, this.tableName}) : super(key: key);

  @override
  _secondPageState createState() => _secondPageState();
}

class _secondPageState extends State<secondPage> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _nameControler = new TextEditingController();
  List<Company> workoutsLists = [];
  int isUsed = 0;
  int count = 0;
  int x = 0;
  List<Company>? dummyList;

  @override
  void initState() {
    // awaiter();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (dummyList != null) {
      workoutsLists = dummyList!;
    }
    var size = MediaQuery.of(context).size;
    Future<bool> _onWillPop() async {
      return (await showDialog(
            builder: (context) => AlertDialog(
              title: Text(
                'Are you sure?',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              content: Text(
                'Want to return back?\nAll data will be lost!',
                style: TextStyle(fontSize: size.width * .045),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: Text('No'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: Text('Yes'),
                ),
              ],
            ),
            context: context,
          )) ??
          false;
    }

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
          body: Stack(children: [
        Column(
          children: [
            Column(children: [
              SizedBox(height: size.height * .05),
              Form(
                key: _formKey,
                child: RoundedInputField(
                  widthSize: size.width * .8,
                  hintText: "Name your plan eg: UpperBody workout",
                  textControler: _nameControler,
                  validator: (value) {
                    return null;
                  },
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                // ignore: prefer_const_literals_to_create_immutables
                children: [
                  const Text(
                    "Your Exercises",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  TextButton(
                    style: TextButton.styleFrom(
                      primary: Colors.grey[500],
                      textStyle: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () async {
                      if (_nameControler.text == '') {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text("Plan's name can't be empty!")));
                      } else if (!(RegExp(r"[^a-z ]", caseSensitive: false)
                              .allMatches(_nameControler.text)
                              .length ==
                          0)) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text("Only letters are alowed!")));
                      } else {
                        await planAdder();
                        Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (BuildContext context) {
                          return HomePage();
                        }));
                      }
                    },
                    child: const Text("Save"),
                  )
                ],
              ),
              Container(
                  width: size.width * .7,
                  child: Divider(
                    height: 1,
                    color: Color(secondColor),
                  )),
            ]),
            Expanded(
                child: ReorderableListView(
              children: workoutsLists.map((e) {
                return GestureDetector(
                  key: Key(e.name),
                  onTap: () {
                    showModalBottomSheet(
                        isScrollControlled: true,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10))),
                        context: context,
                        builder: (BuildContext context) {
                          return bottomPopUp(
                            size: size,
                            dataSecond: e,
                          );
                        });
                  },
                  child: PlansCards(
                    image: CachedNetworkImage(
                        imageUrl: e.imgurl,
                        errorWidget: (context, index, dynami) {
                          return Center();
                        }),
                    title: e.name,
                    size: size,
                    icon: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () async {
                        workoutsLists.remove(e);
                        setState(() {});
                      },
                    ),
                  ),
                );
              }).toList(),
              onReorder: (int oldIndex, int newIndex) {
                setState(() {
                  if (oldIndex < newIndex) {
                    newIndex -= 1;
                  }
                  final item = workoutsLists.removeAt(oldIndex);
                  workoutsLists.insert(newIndex, item);
                });
              },
            ))
          ],
        ),
        Positioned(
          bottom: 10,
          left: size.width * .15,
          right: size.width * .15,
          child: ElevatedButton(
            onPressed: () async {
              final result = await Navigator.push(context,
                  MaterialPageRoute(builder: (BuildContext context) {
                return AddExercise(tableData: workoutsLists);
              })) as List<Company>?;
              dummyList = result!;
              setState(() {});
            },
            child: Text("Add an Exercise"),
            style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Color(secondColor))),
          ),
        )
      ])),
    );
  }

  planAdder() async {
    final database =
        openDatabase(join(await getDatabasesPath(), 'names.db'), version: 2);

    final db = await database;

    try {
      await db.execute(
          'CREATE TABLE "${_nameControler.text}"(ID INT,NAME TEXT,USAGE TEXT,HOWTO TEXT,IMGURL TEXT,ISCHECK TEXT)');
    } catch (e) {}

    for (var i = 0; i < workoutsLists.length; i++) {
      await db.insert("${_nameControler.text}", workoutsLists[i].toMap());
    }
  }
}
