import 'package:builderworkoutplanner/models/exercise_model.dart';
import 'package:builderworkoutplanner/models/time_helper.dart';
import 'package:builderworkoutplanner/pages/congrat_page.dart';
import 'package:builderworkoutplanner/pages/rest_page.dart';
import 'package:builderworkoutplanner/widgets/bottom_popup.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class WorkoutPage extends StatefulWidget {
  final workoutName;
  const WorkoutPage({Key? key, this.workoutName}) : super(key: key);

  @override
  _WorkoutPageState createState() => _WorkoutPageState();
}

class _WorkoutPageState extends State<WorkoutPage> {
  YoutubePlayerController _controller = YoutubePlayerController(
    initialVideoId: 'sAq_ocpRh_I',
  
    flags: YoutubePlayerFlags(
      autoPlay: true,
      mute: false,

    ),
  );
  final controller = PageController();
  int currentExercise = 0;
  Map workoutData = {};
  // List<Map<String,dynamic>> maps = [{''}];

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return FutureBuilder(
        future: dbIniti(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            List<Company> data = snapshot.data;
            double linearValue = (currentExercise + 1) / data.length;

            return Scaffold(
              body: Stack(
                children: [
                  Column(
                    children: [
                      SizedBox(
                        height: size.height * .026,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                              margin: EdgeInsets.all(15),
                              alignment: Alignment.topLeft,
                              child: IconButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  icon: Icon(Icons.arrow_back_ios))),
                          Container(
                              margin: EdgeInsets.all(15),
                              alignment: Alignment.topRight,
                              child: IconButton(
                                  onPressed: () {
                                    // showDiolog(context, data);
                                  },
                                  icon: Icon(Icons.more_horiz))),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Container(
                            width: size.width * .6,
                            child: Text('${data[currentExercise].name}',
                                style: TextStyle(
                                    fontSize: size.height * .025,
                                    fontWeight: FontWeight.bold)),
                          ),
                          Text('${currentExercise + 1}/${data.length}',
                              style: TextStyle(
                                  fontSize: size.height * .038,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      SizedBox(
                        height: size.height * .025,
                      ),
                      Container(
                        width: size.width * .835,
                        height: size.height * 0.025,
                        child: ClipRRect(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          child: LinearProgressIndicator(
                            backgroundColor: Colors.blue[50]!,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              Colors.blue[400]!,
                            ),
                            value: linearValue,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          showModalBottomSheet(
                              isScrollControlled: true,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(10),
                                      topRight: Radius.circular(10))),
                              context: context,
                              builder: (BuildContext context) {
                                return bottomPopUp(
                                    currentExercise: currentExercise,
                                    size: size,
                                    data: data);
                              });
                        },
                        child: Container(
                          width: size.width*.9
                      ,
                          margin: EdgeInsets.only(bottom: 100),
                          alignment: Alignment.center,
                          child: YoutubePlayer(
                            controller: _controller,
                            liveUIColor: Colors.amber,
                            
                          ),
                          // CachedNetworkImage(
                          //     imageUrl: data[currentExercise].imgurl,
                          //     errorWidget: (context, index, dynami) {
                          //       return Center(
                          //         child: Text(
                          //             'Error to recieve data! Please check your network connection.'),
                          //       );
                          //     }),
                        ),
                      ),
                    ],
                  ),
                  Positioned(
                    bottom: size.height * 0.025,
                    right: size.height * .05,
                    left: size.height * .05,
                    child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: Colors.blue.withOpacity(0.07),
                        ),
                        height: 142,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                buildText(
                                  title: 'Sets',
                                  value: '${workoutData['Sets']} times',
                                ),
                                buildText(
                                  title: 'Reps',
                                  value: '${workoutData['Reps']} times',
                                ),
                              ],
                            ),
                            buildButtons(context, data.length),
                          ],
                        )),
                  )
                ],
              ),
            );
          } else {
            return Center();
          }
        });
  }

  // Future<dynamic> showDiolog(BuildContext context, List<Company> data) {
  //   return showDialog(
  //       context: context,
  //       builder: (BuildContext context) => AlertDialog(
  //             shape: RoundedRectangleBorder(
  //                 borderRadius: BorderRadius.circular(15)),
  //             actionsPadding: EdgeInsets.all(15),
  //             actions: [
  //               Center(
  //                   child: Text(
  //                 '${data[currentExercise].name}',
  //                 style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
  //               )),
  //               Column(
  //                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  //                 crossAxisAlignment: CrossAxisAlignment.start,
  //                 children: [
  //                   Container(
  //                     alignment: Alignment.topLeft,
  //                     decoration: BoxDecoration(
  //                         color: Colors.grey[100],
  //                         borderRadius: BorderRadius.circular(15)),
  //                     child: Text(
  //                       ' ${data[currentExercise].howto}',
  //                       style: TextStyle(
  //                           fontSize: 16, fontWeight: FontWeight.bold),
  //                     ),
  //                   ),
  //                   SizedBox(
  //                     height: 2,
  //                   ),
  //                   Container(
  //                     alignment: Alignment.topLeft,
  //                     decoration: BoxDecoration(
  //                         color: Colors.grey[100],
  //                         borderRadius: BorderRadius.circular(15)),
  //                     child: Text(
  //                       'Usage : \n ${data[currentExercise].usage}',
  //                       style: TextStyle(
  //                           fontSize: 16, fontWeight: FontWeight.bold),
  //                     ),
  //                   )
  //                 ],
  //               ),
  //               SizedBox(
  //                 height: 5,
  //               ),
  //               Center(
  //                 child: ElevatedButton(
  //                     onPressed: () async {
  //                       Navigator.pop(context);
  //                     },
  //                     child: Text('Ok')),
  //               )
  //             ],
  //           ));
  // }

  Future<List<Company>> dbIniti() async {
    final db = await openDatabase(join(await getDatabasesPath(), 'names.db'),
        version: 2);

    print("err checker ${widget.workoutName}");

    final List<Map<String, dynamic>> maps =
        await db.query('${widget.workoutName}');

    var workoutsLists = List.generate(maps.length, (index) {
      return Company(
          id: index,
          howto: maps[index]['HOWTO'],
          imgurl: maps[index]['IMGURL'],
          name: maps[index]['NAME'],
          usage: maps[index]['USAGE'],
          sort: index);
    });
    Map dt = await TimeHelper.dataGetter('Settings', 'Setting');
    workoutData = dt;
    return workoutsLists;
  }

  Widget buildText({
    required String title,
    required String value,
  }) =>
      Column(
        children: [
          Text(
            title,
            style: TextStyle(color: Colors.black54),
          ),
          SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ],
      );

  Widget buildButtons(BuildContext context, int totalIndex) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          (currentExercise > 0)
              ? IconButton(
                  icon: Icon(
                    Icons.fast_rewind,
                    color: Colors.black87,
                    size: 32,
                  ),
                  onPressed: () {
                    currentExercise--;
                    setState(() {});
                  },
                )
              : Center(),
          IconButton(
            icon: Icon(
              Icons.fast_forward,
              color: Colors.black87,
              size: 32,
            ),
            onPressed: () async {
              List<Company> data = await dbIniti();
              if (currentExercise >= data.length - 1) {
                TimeHelper.workoutSaver();
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (BuildContext context) {
                  return CongratPage();
                }));
              } else {
                currentExercise++;

                await Navigator.push(context,
                    MaterialPageRoute(builder: (BuildContext context) {
                  return RestPage(
                    currentIndex: currentExercise,
                    totalIndex: totalIndex,
                  );
                }));
                setState(() {});
              }
            },
          ),
        ],
      );

  Widget buildButton(
    BuildContext context, {
    required Widget icon,
    required VoidCallback onClicked,
  }) =>
      GestureDetector(
        onTap: onClicked,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Color(0xFFff6369),
                blurRadius: 8,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: CircleAvatar(
            radius: 24,
            backgroundColor: Color(0xFFff6369),
            child: icon,
          ),
        ),
      );
}
