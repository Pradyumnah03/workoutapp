import 'package:builderworkoutplanner/data.dart';
import 'package:builderworkoutplanner/pages/calendar_page.dart';
import 'package:builderworkoutplanner/pages/settings_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import '../data.dart';
import 'main_page_widget.dart';

class HomePage extends StatefulWidget {
  final int? currIndex;
  const HomePage({Key? key, this.currIndex}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentIndext = 1;
  List<Widget> bars = [CalendarPage(), MainPageWidget(), SettingsPage()];
  @override
  void initState() {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
    ));

    setState(() {
      if (widget.currIndex != null) {
        currentIndext = widget.currIndex!;
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Color(thirdColor),
          unselectedItemColor: Colors.grey[500],
          type: BottomNavigationBarType.shifting,
          currentIndex: currentIndext,
          onTap: (value) {
            setState(() {
              currentIndext = value;
            });
          },
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today),
              label: "Calendar",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: "Settings",
            ),
          ],
        ),
        body: bars[currentIndext]);
  }
}
