const  firstColor = 0xFF00e5ff;
const  secondColor = 0xFF00b0ff;
const  thirdColor = 0xFF3d5afe;
const  fourthColor = 0xFF304ffe;
const lightColor =0xffe1f5fe;
