import 'package:builderworkoutplanner/models/exercise_model.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class bottomPopUp extends StatelessWidget {
  const bottomPopUp({
    Key? key,
     this.currentExercise,
     this.size,
     this.data, this.dataSecond,
  }) : super(key: key);

  final int? currentExercise;
  final Size? size;
  final List<Company>? data;
  final Company? dataSecond;

  @override
  Widget build(BuildContext context) {
    return Container(
        height: size!.height * .7,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                    height: size!.height * .5,
                    child: CachedNetworkImage(
                      imageUrl:(data== null) ?dataSecond!.imgurl: data![currentExercise!].imgurl,
                    )),
              ),
              Container(
                padding: EdgeInsets.only(
                    left: size!.width * .1, right: size!.width * .1),
                child: Text((data== null) ?dataSecond!.name: data![currentExercise!].name,
                    style: TextStyle(
                        fontSize: size!.height * .025,
                        fontWeight: FontWeight.bold)),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                padding: EdgeInsets.only(
                    left: size!.width * .1, right: size!.width * .1),
                child: Text((data== null) ?dataSecond!.usage:data![currentExercise!].usage,
                    style: TextStyle(
                      fontSize: size!.height * .025,
                    )),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                padding: EdgeInsets.only(
                    left: size!.width * .1, right: size!.width * .1),
                child: Text((data== null) ?dataSecond!.howto:'${data![currentExercise!].howto}',
                    style: TextStyle(
                      fontSize: size!.height * .025,
                    )),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
        ));
  }
}
