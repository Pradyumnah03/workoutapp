// To parse this JSON data, do
//
//     final exerciseModel = exerciseModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

// ExerciseModel exerciseModelFromJson(String str) =>
//     ExerciseModel.fromJson(json.decode(str));

String exerciseModelToJson(ExerciseModel data) => json.encode(data.toJson());

class ExerciseModel {
  ExerciseModel({
    required this.company,
  });

  List<Company> company;

  // factory ExerciseModel.fromJson(Map<String, dynamic> json) => ExerciseModel(
  //       company:
  //           List<Company>.from(json["COMPANY"].map((x) => Company.fromJson(x))),
  //     );

  Map<String, dynamic> toJson() => {
        "COMPANY": List<dynamic>.from(company.map((x) => x.toMap())),
      };
}

class Company {
  Company({
    this.sort,
    required this.id,
    required this.name,
    required this.usage,
    required this.howto,
    required this.imgurl,
    this.ischeck,
  });

  int id;
  String name;
  String usage;
  String howto;
  String imgurl;
  int? ischeck;
  int? sort;

  // factory Company.fromJson(Map<String, dynamic> json) => Company(
  //       id: json["ID"],
  //       name: json["NAME"],
  //       usage: json["USAGE"],
  //       howto: json["HOWTO"],
  //       imgurl: json["IMGURL"],
  //       ischeck: json["ISCHECK"],
  //     );

  Map<String, dynamic> toMap() => {
        "ID": id,
        "NAME": name,
        "USAGE": usage,
        "HOWTO": howto,
        "IMGURL": imgurl,
        "ISCHECK": ischeck,
      };

  @override
  String toString() {
    return 'Company{id : $id, name: $name, usage = $usage, how to = $howto, img_url = $imgurl,sort = $sort}';
  }
}

class AddNewCompany {
  AddNewCompany({
    required this.id,
    required this.name,
    required this.usage,
    required this.howto,
    required this.imgurl,
  });

  int id;
  String name;
  String usage;
  String howto;
  String imgurl;

  factory AddNewCompany.fromJson(Map<String, dynamic> json) => AddNewCompany(
        id: json["ID"],
        name: json["NAME"],
        usage: json["USAGE"],
        howto: json["HOWTO"],
        imgurl: json["IMGURL"],
      );

  Map<String, dynamic> toMap() => {
        "ID": id,
        "NAME": name,
        "USAGE": usage,
        "HOWTO": howto,
        "IMGURL": imgurl,
      };

  @override
  String toString() {
    return 'Company{id : $id, name: $name, usage = $usage, how to = $howto, img_url = $imgurl}';
  }
}

class NamesOfPlans {
  NamesOfPlans({
    required this.id,
    required this.name,
    this.isUsed,
  });

  int id;
  String name;
  final isUsed;

  Map<String, dynamic> toMap() => {"ID": id, "NAME": name, "ISUSED": isUsed};

  @override
  String toString() {
    return 'Company{id : $id, name: $name,isused:$isUsed}';
  }
}
