class Event{
final String title;

  Event({required this.title});

  @override
  String toString() {
    // TODO: implement toString
    return this.title;
  }

}